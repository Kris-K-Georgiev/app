import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:bhss/services/api_client.dart';
import 'package:bhss/providers/auth_provider.dart';

// Because flutter_secure_storage uses platform channels, we simulate by overriding method channel behavior via a Fake.
// For simplicity in this lightweight test we monkey-patch by extending and injecting a test double would require refactor.
// Here we focus on migration logic path: moving legacy SharedPreferences token into secure storage triggers api.token assignment.

void main(){
  TestWidgetsFlutterBinding.ensureInitialized();
  group('AuthProvider migration', (){
    testWidgets('migrates legacy token from SharedPreferences to secure storage', (tester) async {
      SharedPreferences.setMockInitialValues({'token':'legacy-token-123'});
      final api = ApiClient(null);
      // Build a minimal widget tree to instantiate provider.
      await tester.pumpWidget(MultiProvider(
        providers:[ChangeNotifierProvider(create: (_)=> AuthProvider(api))],
        child: const MaterialApp(home: SizedBox.shrink()),
      ));
      await tester.pumpAndSettle();
      expect(api.token, equals('legacy-token-123'));
    });
  });
}
