import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:bhss/providers/content_provider.dart';
import 'package:bhss/providers/auth_provider.dart';
import 'package:bhss/providers/theme_provider.dart';
import 'package:bhss/services/api_client.dart';
import 'package:bhss/services/content_service.dart';
import 'package:bhss/models/event.dart';
import 'package:bhss/models/news.dart';
import 'package:bhss/models/app_version.dart';
import 'package:bhss/screens/home_screen.dart';

class _Service implements IContentService {
  List<EventItem> mockEvents;
  _Service(this.mockEvents);
  @override
  Future<(List<NewsItem>, bool)> fetchNews({int page=1,int perPage=10}) async => (<NewsItem>[], false);
  @override
  Future<List<EventItem>> fetchEvents({String? status,String? type,String? audience,String? city}) async {
    if(status==null || status=='active') return mockEvents.where((e)=> e.status=='active').toList();
    if(status=='inactive') return mockEvents.where((e)=> e.status=='inactive').toList();
    return mockEvents;
  }
  @override
  Future<(List<EventItem>, bool)> fetchEventsPaged({int page=1,int perPage=20,String? status,String? type,String? audience,String? city}) async => (await fetchEvents(status: status, type: type, audience: audience, city: city), false);
  @override
  Future<AppVersionInfo?> latestVersion() async => null;
}

EventItem _evt(int id,String status)=> EventItem(id: id, title: 'E$id', description: null, startDate: DateTime.now(), endDate: DateTime.now(), startTime: null, location: null, cover: null, city: 'София', audience: 'open', limit: null, registrationsCount: 0, images: const [], days: 1, userStatus: null, status: status, type: null);

void main(){
  testWidgets('Changing status filter updates event list', (tester) async {
    final events = [_evt(1,'active'), _evt(2,'inactive'), _evt(3,'active')];
    final service = _Service(events);
    await tester.pumpWidget(MultiProvider(providers:[
      ChangeNotifierProvider(create: (_)=> ThemeProvider()),
      ChangeNotifierProvider(create: (_)=> AuthProvider(ApiClient(null))),
      ChangeNotifierProvider(create: (_)=> ContentProvider(service)),
    ], child: const MaterialApp(home: HomeScreen())));

    // initial loadAll is async: pump microtasks
    await tester.pump(const Duration(milliseconds:10));
    await tester.pump(const Duration(milliseconds:600));

    // By default status active => only active events count =2
    expect(find.text('E1'), findsOneWidget);
    expect(find.text('E3'), findsOneWidget);
    expect(find.text('E2'), findsNothing);

    // Tap status chip 'Неактивни'
    final inactiveChip = find.widgetWithText(ChoiceChip, 'Неактивни');
    expect(inactiveChip, findsOneWidget);
    await tester.tap(inactiveChip);
    await tester.pumpAndSettle();

    expect(find.text('E2'), findsOneWidget);
    expect(find.text('E1'), findsNothing);
  });
}
