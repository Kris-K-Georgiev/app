import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:bhss/ui/meta_chip.dart';
import 'package:bhss/theme/shad_theme.dart';

void main(){
  testWidgets('MetaChip renders label and reacts to tap', (tester) async {
    int taps = 0;
    await tester.pumpWidget(MaterialApp(
      theme: ShadTheme.light(),
      home: Scaffold(body: Center(child: MetaChip(label: 'Тест', onTap: (){ taps++; }))),
    ));
    expect(find.text('Тест'), findsOneWidget);
    await tester.tap(find.text('Тест'));
    await tester.pumpAndSettle();
    expect(taps, 1);
  });

  testWidgets('MetaChip dense + dot renders', (tester) async {
    await tester.pumpWidget(MaterialApp(
      theme: ShadTheme.dark(),
      home: const Scaffold(body: Center(child: MetaChip(label: 'BG', dotColor: Colors.red, dense: true))),
    ));
    expect(find.text('BG'), findsOneWidget);
  });
}
