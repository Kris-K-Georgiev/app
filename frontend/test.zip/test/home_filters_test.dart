import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:bhss/providers/auth_provider.dart';
import 'package:bhss/models/news.dart';
import 'package:bhss/models/event.dart';
import 'package:bhss/models/app_version.dart';
import 'package:bhss/providers/content_provider.dart';
import 'package:bhss/providers/theme_provider.dart';
import 'package:bhss/services/api_client.dart';
import 'package:bhss/services/content_service.dart';
import 'package:bhss/screens/home_screen.dart';

class _FakeContentService implements IContentService {
  @override
  Future<(List<NewsItem>, bool)> fetchNews({int page = 1, int perPage = 10}) async => (<NewsItem>[], false);
  @override
  Future<List<EventItem>> fetchEvents({String? status, String? type, String? audience, String? city}) async => <EventItem>[];
  @override
  Future<(List<EventItem>, bool)> fetchEventsPaged({int page = 1, int perPage = 20, String? status, String? type, String? audience, String? city}) async => (<EventItem>[], false);
  @override
  Future<AppVersionInfo?> latestVersion() async => null;
}

void main(){
  testWidgets('Profile initials fallback hidden on home (avatar removed)', (tester) async {
    final api = ApiClient(null);
    final auth = AuthProvider(api);
    // leave unauthenticated to assert avatar not shown (home avatar removed entirely)
    await tester.pumpWidget(MultiProvider(providers: [
      ChangeNotifierProvider(create: (_)=> ThemeProvider()),
      ChangeNotifierProvider(create: (_)=> auth),
      ChangeNotifierProvider(create: (_)=> ContentProvider(_FakeContentService())),
    ], child: const MaterialApp(home: HomeScreen())));
    await tester.pumpAndSettle();
    // Ensure no CircleAvatar present on home actions now
    expect(find.byType(CircleAvatar), findsNothing);
  });
}
