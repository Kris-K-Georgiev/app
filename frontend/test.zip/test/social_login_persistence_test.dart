import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:bhss/services/api_client.dart';
import 'package:bhss/providers/auth_provider.dart';

class FakeApiClient extends ApiClient {
  FakeApiClient(): super(null);
  @override
  Future<dynamic> post(String path, Map body) async {
    if(path=='/auth/social'){
      return {
        'token':'social-token-xyz',
        'user': {'id':1,'name': body['name'] ?? 'Social User','email': body['email'] ?? 'user@example.com'}
      };
    }
    return super.post(path, body);
  }
  @override
  Future<dynamic> get(String path) async {
    if(path=='/auth/me'){
      return {'id':1,'name':'Social User','email':'user@example.com'};
    }
    return super.get(path);
  }
}

void main(){
  TestWidgetsFlutterBinding.ensureInitialized();
  testWidgets('social login stores token in secure layer (migration removes legacy)', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final api = FakeApiClient();
    await tester.pumpWidget(MultiProvider(
      providers: [ChangeNotifierProvider(create: (_)=> AuthProvider(api))],
      child: const MaterialApp(home: SizedBox.shrink()),
    ));
    await tester.pump();
  // Obtain provider via context
  final ctx = tester.element(find.byType(SizedBox));
  final auth = Provider.of<AuthProvider>(ctx, listen: false);
  await auth.loginWithSocial(provider: 'google', idToken: 'fake');
  expect(api.token, 'social-token-xyz');
  });
}
