import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:bhss/widgets/adaptive_logo.dart';

void main(){
  testWidgets('Light and dark logo mount without errors', (tester) async {
    await tester.pumpWidget(MaterialApp(theme: ThemeData.light(useMaterial3: true), home: const Scaffold(body: AdaptiveLogo())));
    expect(find.byType(AdaptiveLogo), findsOneWidget);
    await tester.pumpWidget(MaterialApp(theme: ThemeData.dark(useMaterial3: true), home: const Scaffold(body: AdaptiveLogo())));
    await tester.pump();
    expect(find.byType(AdaptiveLogo), findsOneWidget);
  });
}
