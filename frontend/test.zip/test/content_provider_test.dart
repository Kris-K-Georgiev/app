import 'package:flutter_test/flutter_test.dart';
import 'package:bhss/providers/content_provider.dart';
import 'package:bhss/services/content_service.dart';
import 'package:bhss/models/news.dart';
import 'package:bhss/models/event.dart';
import 'package:bhss/models/app_version.dart';

// A lightweight fake Api client layer for unit test (no HTTP)
class _FakeContentService implements IContentService {
  @override
  Future<(List<NewsItem>, bool)> fetchNews({int page = 1, int perPage = 10}) async => ([
        NewsItem(id: 2, title: 'Second', content: '<p>Hi</p>', images: const [], createdAt: DateTime.now()),
        NewsItem(id: 1, title: 'First', content: '<p>Hi</p>', images: const [], createdAt: DateTime.now().subtract(const Duration(days: 1))),
      ], false);

  @override
  Future<List<EventItem>> fetchEvents({String? status, String? type, String? audience, String? city}) async => [
        EventItem(
          id: 1,
          title: 'Event',
          description: null,
          startDate: DateTime.now(),
          endDate: null,
          startTime: null,
          location: null,
          cover: null,
          city: 'Sofia',
          audience: 'open',
          limit: null,
          registrationsCount: null,
          images: const [],
          days: null,
          userStatus: null,
          status: 'active',
          type: null,
        )
      ];

  @override
  Future<(List<EventItem>, bool)> fetchEventsPaged({int page = 1, int perPage = 20, String? status, String? type, String? audience, String? city}) async => (await fetchEvents(status: status, type: type, audience: audience, city: city), false);

  @override
  Future<AppVersionInfo?> latestVersion() async => null;
}

void main(){
  group('ContentProvider basic parsing', (){
    test('loadAll populates news & events', () async {
      final provider = ContentProvider(_FakeContentService());
      await provider.loadAll();
      expect(provider.news.length, 2);
      expect(provider.events.length, 1);
      expect(provider.news.first.id, 2); // preserve ordering from fake
    });
  });
}
