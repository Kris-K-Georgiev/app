import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:frontend/widgets/list/adaptive_list_card.dart';
import 'package:frontend/theme/shad_theme.dart';

void main(){
  testWidgets('AdaptiveListCard renders title and value', (tester) async {
    await tester.pumpWidget(MaterialApp(
      theme: ShadTheme.light(),
      home: Scaffold(
        body: Row(children:[
          Expanded(child: AdaptiveListCard(title: 'Публикации', value: '12', leading: const Icon(Icons.article))),
        ]),
      ),
    ));

    expect(find.text('Публикации'), findsOneWidget);
    expect(find.text('12'), findsOneWidget);
    expect(find.byIcon(Icons.article), findsOneWidget);
  });

  testWidgets('AdaptiveListCard tap callback fires', (tester) async {
    int taps = 0;
    await tester.pumpWidget(MaterialApp(
      theme: ShadTheme.light(),
      home: Scaffold(body: AdaptiveListCard(title: 'Тест', onTap: (){ taps++; })),
    ));

    await tester.tap(find.text('Тест'));
    await tester.pumpAndSettle();

    expect(taps, 1);
  });

  testWidgets('AdaptiveListCard renders subtitle and works in dark theme', (tester) async {
    await tester.pumpWidget(MaterialApp(
      theme: ShadTheme.dark(),
      home: const Scaffold(
        body: AdaptiveListCard(title: 'Събития', value: '3', subtitle: 'активни', leading: Icon(Icons.event)),
      ),
    ));

    expect(find.text('Събития'), findsOneWidget);
    expect(find.text('3'), findsOneWidget);
    expect(find.text('активни'), findsOneWidget);
    expect(find.byIcon(Icons.event), findsOneWidget);
  });
}
