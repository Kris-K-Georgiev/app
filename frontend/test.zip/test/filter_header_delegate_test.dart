import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:bhss/ui/filter_header_delegate.dart';

void main(){
  testWidgets('FilterHeaderDelegate builds child and respects extents', (tester) async {
    const delegate = FilterHeaderDelegate(minExtent: 56, maxExtent: 90, child: SizedBox(height: 70, child: Text('Filters')));
    await tester.pumpWidget(MaterialApp(
      home: CustomScrollView(
        slivers: [
          SliverPersistentHeader(delegate: delegate, pinned: true),
          SliverList(delegate: SliverChildBuilderDelegate((_,i)=> ListTile(title: Text('Item $i')), childCount: 5)),
        ],
      ),
    ));
    expect(find.text('Filters'), findsOneWidget);
  });
}
