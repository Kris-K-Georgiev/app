import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:bhss/providers/content_provider.dart';
import 'package:bhss/services/content_service.dart';
import 'package:bhss/screens/events_tab.dart';
// We won't import the real auth provider to avoid depending on its implementation.
import 'package:bhss/models/news.dart';
import 'package:bhss/models/event.dart';
import 'package:bhss/models/app_version.dart';
import 'package:flutter/foundation.dart';

// A fake content service to simulate various responses and ensure the EventsTab doesn't crash
class _FakeContentService implements IContentService {
  bool throwEvents;
  _FakeContentService({this.throwEvents = false});

  @override
  Future<(List<NewsItem>, bool)> fetchNews({int page = 1, int perPage = 10}) async => (const <NewsItem>[], false);

  @override
  Future<List<EventItem>> fetchEvents({String? status, String? type, String? audience, String? city}) async {
    if (throwEvents) throw Exception('events fail');
    return const <EventItem>[];
  }

  @override
  Future<(List<EventItem>, bool)> fetchEventsPaged({int page = 1, int perPage = 20, String? status, String? type, String? audience, String? city}) async {
    if (throwEvents) throw Exception('paged events fail');
    return (const <EventItem>[], false);
  }

  @override
  Future<AppVersionInfo?> latestVersion() async => null;
}


void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp((){ SharedPreferences.setMockInitialValues({}); });

  Widget wrap(Widget child, {bool fail = false}) {
    final fake = _FakeContentService(throwEvents: fail);
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ContentProvider(fake)),
      ],
      child: MaterialApp(home: Scaffold(body: child)),
    );
  }

  Future<void> pumpUntil(WidgetTester tester, bool Function() condition,
      {Duration timeout = const Duration(seconds: 5), Duration step = const Duration(milliseconds: 50)}) async {
    final start = DateTime.now();
    while (!condition()) {
      if (DateTime.now().difference(start) > timeout) {
        return; // give up – assertion will fail afterwards
      }
      await tester.pump(step);
    }
  }

  testWidgets('EventsTab loads empty state without crashing', (tester) async {
    await tester.pumpWidget(wrap(const EventsTab()));
    // Allow async reload to finish
    await pumpUntil(tester, () => find.text('Няма събития').evaluate().isNotEmpty);
    expect(find.text('Няма събития'), findsOneWidget, reason: 'Empty state should appear for no events');
  });

  testWidgets('EventsTab shows error banner when service throws', (tester) async {
    await tester.pumpWidget(wrap(const EventsTab(), fail: true));
    // Wait until provider finishes loading (eventsLoading -> false)
    await pumpUntil(tester, () {
      final eventsTabFinder = find.byType(EventsTab);
      if (eventsTabFinder.evaluate().isEmpty) return false;
      final ctx = tester.element(eventsTabFinder);
      final prov = Provider.of<ContentProvider>(ctx, listen: false);
      return !prov.eventsLoading; // finished attempt
    });
    // One more small pump to let rebuild settle
    await tester.pump(const Duration(milliseconds: 50));
    final ctx = tester.element(find.byType(EventsTab));
    final prov = Provider.of<ContentProvider>(ctx, listen: false);
    debugPrint('[test] eventsLoading=${prov.eventsLoading} eventsError=${prov.eventsError} events=${prov.events.length}');
    // If eventsError not set, the thrown exception may have bubbled before provider captured it.
    expect(prov.eventsError, isTrue, reason: 'Provider should flag eventsError when fetch throws');
    // Give a final frame for banner
    await tester.pump(const Duration(milliseconds: 50));
    expect(find.text('Грешка при зареждане на събития'), findsOneWidget, reason: 'Error banner should appear when service throws');
  });
}
